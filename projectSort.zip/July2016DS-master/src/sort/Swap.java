package sort;

/**
 * Created by rrt on 8/6/2016.
 */
public class Swap {
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 20;

        int temp = num1;
        num1 = num2;
        num2 = temp;
        System.out.println(num1);
        System.out.println(num2);
    }
}
